import json
from utils import sqlFetch,cursor_to_list,internalError,getSuccess,postSuccess
import time

def getQuestionTable(event,context):
    conn, cursor = sqlFetch()
    try:
        cursor.execute("select * from dev.question;")    
        json_data = json.dumps(cursor_to_list(cursor),default=str)
        return getSuccess(json_data)
    except Exception as e:
        return internalError(e)

def getQuestionTableParms(event,context):
    conn, cursor = sqlFetch()
    query_parms =event['queryStringParameters']
    try:
        cursor.execute("select * from dev.question;")    
        json_data = json.dumps(cursor_to_list(cursor),default=str)
        return getSuccess(json_data)
    except Exception as e:
        return internalError(e)

def getQuestionID(event,context):
    conn, cursor = sqlFetch()
    try:
        table_id=event['pathParameters']['table_id']
        sql_execute="select * from dev.question where id=%s"%(table_id)
        cursor.execute(sql_execute)
        json_data = json.dumps(cursor_to_list(cursor),default=str)
        return getSuccess(json_data)
    except Exception as e:
        return internalError(e)

def insertQuestion(event,context):
    conn, cursor = sqlFetch()
    try:
        insert_dict = json.loads(event['body'])
        insert_values='(' + str(int(time.time())) +","
        for key in insert_dict.keys():
            if key == 'id':
                pass
            else:
                insert_values += "'"+str(insert_dict[key])+"'" + ","
        insert_values = insert_values.strip(",") + ")"       
        heading_list = list(insert_dict.keys())
        if 'id' in heading_list:
            heading_list.remove('id')
        heading_list = ['id'] + heading_list        
        insert_headings = str(tuple(heading_list)).replace("'","").strip(",")
        sql_execute="insert into dev.question " + str(insert_headings) + " values "+insert_values+";"
        cursor.execute(sql_execute)
        conn.commit()
        return postSuccess()
    except Exception as e:
        return internalError(e)

def deleteQuestionID(event,context):
    conn, cursor = sqlFetch()
    try:
        table_id=event['pathParameters']['table_id']
        sql_execute="delete from dev.question where id=%s"%(table_id)
        cursor.execute(sql_execute)
        conn.commit()
        return postSuccess("Deleted successfully")
    except Exception as e:
        return internalError(e)        
