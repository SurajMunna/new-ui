import psycopg2
import sys
import json
from datetime import datetime

config = 'dbname=quizdb user=postgres password=hMrYk35nzRy6NFW5J1u4 host=ahaguru-analytics-datastore.c0lxzvsjnoqb.ap-south-1.rds.amazonaws.com'
    
def sqlFetch():
    try:
        conn = psycopg2.connect(config)
        cursor = conn.cursor()     
        return conn,cursor
    except:
        print("error while connecting")
        return 0,0

def cursor_to_list(cursor):
    heading = [i[0] for i in cursor.description]
    list_data = []
    for row in cursor:
        each_data = {}
        for index, key in enumerate(heading):
            if key == 'course_json' and type(row[index]) == str:
                each_data[key] = json.loads(row[index])
            else:        
                each_data[key] = row[index]
        list_data.append(each_data)
    return(list_data) 

def internalError(e):
    return{
            "statusCode": 500,
            "headers": {
            'Access-Control-Allow-Headers': '*',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'POST,GET'
            },
            "body": json.dumps({
                "error":str(e)
            }), 
        }        


def postSuccess(msg="Record added successfully"):
    return{
            "statusCode": 200,
            "headers": {
            'Access-Control-Allow-Headers': '*',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'POST,GET'
            },
            "body": json.dumps({
                "msg":msg
            }), 
        }


def getSuccess(json_data):
    return{
            "statusCode": 200,
            "headers": {
            'Access-Control-Allow-Headers': '*',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'POST,GET'
            },
            "body": json_data, 
        }                  