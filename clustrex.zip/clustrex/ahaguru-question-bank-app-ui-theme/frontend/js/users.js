let currDeluser;
let datTable;
$(document).ready(function () {
  datTable = $("#question-table").DataTable();
});
 axios
        .get(
          "https://x7j15x2iil.execute-api.ap-south-1.amazonaws.com/Prod/user"
        )
        .then((res) => {
          console.log(res.data);
          renderTable(res.data);
        })
        .catch((err) => {
          console.log(err.message);
        });

      function renderTable(data) {
       // let table = document.querySelector("#question-table");
       // table.innerHTML = table.innerHTML + "<tbody>"
        data.map((elm, index) => {
let tr = document.createElement("TR");
         tr.id = `row-${elm.id}`;
         
          // questionID
          let name = document.createElement("TD");
          name.innerHTML = `<p>${elm.name}</p>`;
 
 
 
 

          // QuestionName
          let phone_number = document.createElement("TD");
          phone_number.innerHTML = `<p>${elm.phonenumber}</p>`;

          // Action
          let address = document.createElement("TD");
           address.innerHTML = `<p>${elm.address}</p>`;
 
  let action = document.createElement("TD");
         action.innerHTML = `<a data-widget="pushmenu" id="menuicon" onclick='editQuestion("${elm.id}")' role="button"><i class="fas fa-pen"></i></a><span> </span><a  data-widget="pushmenu" id="menuicon" type="button" data-toggle="modal" data-target="#staticBackdrop" onclick='setDeleteQn(${elm.id})' role="button"><i class="fas fa-trash"></i></a> `;

          tr.appendChild(name);
          tr.appendChild(phone_number);
          tr.appendChild(address);
 tr.appendChild(action);

          datTable.row.add(tr);
        });
 datTable.draw();
       // table.innerHTML = table.innerHTML + "</tbody>"
      }

   function setDeleteQn(id) {
  currDeluser = id;
}

function editQuestion(id) {
  localStorage.setItem("usreditable", id);
  window.location.href = "./edituser.html";
}

function removeQuestion() {
  axios
    .delete(
      ` https://x7j15x2iil.execute-api.ap-south-1.amazonaws.com/Prod/user/${currDeluser}`
 
    )
    .then((res) => {
      var elm = document.querySelector(`#row-${currDeluser}`);
      elm.remove();
    })
    .catch((err) => {
      alert("Unable to delete");
    });
}