let currDelvoc;
let datTable;

$(document).ready(function () {
  datTable = $("#question-table").DataTable();
});

axios
  .get("https://0t88rwdsy4.execute-api.ap-south-1.amazonaws.com/Prod/vocabulary")
  .then((res) => {
    renderTable(res.data);
    console.log(res.data);
  })
  .catch((err) => {
    console.log(err.message);
  });

function renderTable(data) {
  // let table = document.querySelector("#question-table");
  // table.innerHTML = table.innerHTML + "<tbody>";
  data.map((elm, index) => {
    let tr = document.createElement("TR");
    tr.id = `row-${elm.id}`;

    // QuestionName
    let name = document.createElement("TD");
    name.innerHTML = `<p>${elm.name}</p>`;

    // desc
    let description = document.createElement("TD");
    description.innerHTML = `<p>${elm.description}</p>`;

    // Action
    let action = document.createElement("TD");
    //action.innerHTML = `<a href='#' class="side-btn" onclick='editQuestion(${elm.id})'>Edit</a><span> </span><a href='#' type="button" data-toggle="modal" data-target="#staticBackdrop" class="side-btn" onclick="setDeleteQn(${elm.id})">Delete</a>`;
    action.innerHTML = `<a data-widget="pushmenu" id="menuicon" onclick='editQuestion("${elm.id}")' role="button"><i class="fas fa-pen"></i></a><span>      </span><a data-widget="pushmenu" id="menuicon" type="button" data-toggle="modal" data-target="#staticBackdrop" onclick='setDeleteQn(${elm.id})' role="button"><i class="fas fa-trash"></i></a> `;


    tr.appendChild(name);
    tr.appendChild(description);
    tr.appendChild(action);

    datTable.row.add(tr);
  });
  datTable.draw();
  //table.innerHTML = table.innerHTML + "</tbody>";
}

function setDeleteQn(vcid) {
  currDelvoc = vcid;
}

function editQuestion(vcid) {
  localStorage.setItem("vceditable", vcid);
  window.location.href = "./vedit.html";
}

function removeQuestion() {
  axios
    .delete(
      `https://0t88rwdsy4.execute-api.ap-south-1.amazonaws.com/Prod/vocabulary/${currDelvoc}`
    )
    .then((res) => {
      var elm = document.querySelector(`#row-${currDelvoc}`);
      elm.remove();
    })
    .catch((err) => {
      alert("Unable to delete");
    });
}
