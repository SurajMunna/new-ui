$(document).ready(function () {

    axios.get('https://x7j15x2iil.execute-api.ap-south-1.amazonaws.com/Prod/vocabulary')
      .then(res=>{
        let data = res.data;
        data.map((item,index)=>{
          let elm = document.querySelector('#parentname');
          elm.innerHTML += `<option value="${item.name}">${item.name}</option>`
        })
      })
      
      .catch(err=>{
        console.log(err);
      })

    $("#question-form").on("submit", function (event) {
      var myData = {
        name: $("#name").val(),
        description: $("#desc").val(),
        parentid:$("#ptid").val(),
        exclusive:$("#exclusive").val()
      };
  
      console.log(myData);
  
      axios
        .post(
          "https://0t88rwdsy4.execute-api.ap-south-1.amazonaws.com/Prod/vocabulary",
          myData
        )
        .then((res) => {
          alert("Inserted");
        })
        .catch((err) => {
          alert("Unable to Insert");
        });
      event.preventDefault();
    });
  });
  