$(document).ready(function()
{
  $('#question-form').on('submit',function(event)
  {

    var myData = {
      name : $("#name").val(),
      phone_number : $("#ph").val(),
      address : $("#ad").val(),
     
    }

    console.log(myData)

    axios.post('https://x7j15x2iil.execute-api.ap-south-1.amazonaws.com/Prod/user', myData).then((res)=>{
      alert("Inserted")
    }).catch((err)=>{
      alert("Unable to Insert")
    })
    event.preventDefault();
  })
})