$(document).ready(function () {
    let id = localStorage.getItem("usreditable");
    if (!id) {
      window.location.href = "./users.html";
    }
    axios
      .get(
        `https://x7j15x2iil.execute-api.ap-south-1.amazonaws.com/Prod/user`
      )
      .then((res) => {
        let data = res.data[0];
        document.querySelector("#name").value = data["name"];
        document.querySelector("#ph").value = data["phonenumber"];
        document.querySelector("#ad").value = data["address"];
  
      })
      .catch((err) => {
        console.log(err);
      });
  });
  
  $("#question-form").on("submit", function (event) {
    let userid = localStorage.getItem("usreditable");
    var myData = {
       name : $("#name").val(),
          phonenumber : $("#ph").val(),
          address : $("#ad").val()
  
    };
  
    console.log(myData);
  
    axios
      .patch(
        `  https://x7j15x2iil.execute-api.ap-south-1.amazonaws.com/Prod/user/${userid}`,
  
        myData
      )
      .then((res) => {
        alert("Updated");
        window.location.href = './users.html'
      })
      .catch((err) => {
        console.log(err);
        alert("Unable to update");
      });
  
    event.preventDefault();
  });