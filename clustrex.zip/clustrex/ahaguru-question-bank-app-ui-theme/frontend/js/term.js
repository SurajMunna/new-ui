$(document).ready(function () {

    axios.get('https://x7j15x2iil.execute-api.ap-south-1.amazonaws.com/Prod/vocabulary')
    .then(res=>{
        let data = res.data;
      data.map((item,index)=>{
        let elm = document.querySelector('#parentname');
        elm.innerHTML += `<option value="${item.name}">${item.name}</option>`
      })
    })
    
    .catch(err=>{
      console.log(err);
    })
})
    
