$(document).ready(function () {
  axios.get('https://x7j15x2iil.execute-api.ap-south-1.amazonaws.com/Prod/vocabulary')
  .then(res=>{
    let data = res.data;
    data.map((item,index)=>{
      let elm = document.querySelector('#parentname');
      elm.innerHTML += `<option value="${item.name}">${item.name}</option>`
    })
  })
  
  .catch(err=>{
    console.log(err);
  })
    let vcid = localStorage.getItem("vceditable");
    if (!vcid) {
      window.location.href = "./vocabulary.html";
    }
    axios
      .get(
        `https://0t88rwdsy4.execute-api.ap-south-1.amazonaws.com/Prod/vocabulary/${vcid}`
      )
      .then((res) => {
        let data = res.data[0];
        console.log(res);
        document.querySelector("#name").value = data["name"];
        document.querySelector("#desc").value = data["description"];
        document.querySelector("#ptid").value = data["parentid"];
        document.querySelector("#exclusive").value = data["exclusive"];
      })
      .catch((err) => {
        console.log(err);
      });
  });
  
  $("#question-form").on("submit", function (event) {
    let vcid = localStorage.getItem("vceditable");
    var myData = {
      name: $("#name").val(),
      description: $("#desc").val(),
      parentid: $("#ptid").val(),
      exclusive: $("#exclusive").val(),
    };
  
    console.log(myData);
  
    axios
      .patch(
        `https://0t88rwdsy4.execute-api.ap-south-1.amazonaws.com/Prod/vocabulary/${vcid}`,
        myData
      )
      .then((res) => {
        alert("Updated");
        window.location.href = './vocabulary.html'
      })
      .catch((err) => {
        console.log(err);
        alert("Unable to update");
      });
  
    event.preventDefault();
  });
  