let currDelQn;
let datTable;

$(document).ready(function () {
  datTable = $("#question-table").DataTable();
});

axios
  .get("https://x7j15x2iil.execute-api.ap-south-1.amazonaws.com/Prod/question")
  .then((res) => {
    renderTable(res.data);
    console.log(res.data);
  })
  .catch((err) => {
    console.log(err.message);
  });

function renderTable(data) {
  // let table = document.querySelector("#question-table");
  // table.innerHTML = table.innerHTML + "<tbody>";
  data.map((elm, index) => {
    let tr = document.createElement("TR");
    tr.id = `row-${elm.id}`;

    // QuestionName
    let qname = document.createElement("TD");
    qname.innerHTML = `<p>${elm.q_text}</p>`;

    // questionCreated
    let questionCreated = document.createElement("TD");
    questionCreated.innerHTML = `<p>${elm.created}</p>`;

    // questionModified
    let questionModified = document.createElement("TD");
    questionModified.innerHTML = `<p>${elm.modified}</p>`;

    // Action
    let action = document.createElement("TD");
    //action.innerHTML = `<a href='#' class="side-btn" onclick='editQuestion(${elm.id})'>Edit</a><span> </span><a href='#' type="button" data-toggle="modal" data-target="#staticBackdrop" class="side-btn" onclick="setDeleteQn(${elm.id})">Delete</a>`;
    action.innerHTML = `<a data-widget="pushmenu" id="menuicon" onclick='editQuestion("${elm.id}")' role="button"><i class="fas fa-pen"></i></a><span> </span><a data-widget="pushmenu" id="menuicon" type="button" data-toggle="modal" data-target="#staticBackdrop" onclick='setDeleteQn(${elm.id})' role="button"><i class="fas fa-trash"></i></a> `;


    tr.appendChild(qname);
    tr.appendChild(questionCreated);
    tr.appendChild(questionModified);
    tr.appendChild(action);

    datTable.row.add(tr);
  });
  datTable.draw();
  //table.innerHTML = table.innerHTML + "</tbody>";
}

function setDeleteQn(qid) {
  currDelQn = qid;
}

function editQuestion(qid) {
  localStorage.setItem("editable", qid);
  window.location.href = "./edit.html";
}

function removeQuestion() {
  axios
    .delete(
      `https://x7j15x2iil.execute-api.ap-south-1.amazonaws.com/Prod/question/${currDelQn}`
    )
    .then((res) => {
      var elm = document.querySelector(`#row-${currDelQn}`);
      elm.remove();
    })
    .catch((err) => {
      alert("Unable to delete");
    });
}
