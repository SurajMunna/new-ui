$(document).ready(function () {
  let qid = localStorage.getItem("editable");
  if (!qid) {
    window.location.href = "./questions.html";
  }
  axios
    .get(
      `https://x7j15x2iil.execute-api.ap-south-1.amazonaws.com/Prod/question/${qid}`
    )
    .then((res) => {
      let data = res.data[0];
      console.log(data);
      //document.querySelector("#head-title").innerHTML = `Edit Question #${qid}`;
      document.querySelector("#qtext").value = data["q_text"];
      document.querySelector("#qimage").value = data["q_image"];
      document.querySelector("#qtype").value = data["q_type"];
      document.querySelector("#ch1").value = data["ch1_text"];
      document.querySelector("#ch1img").value = data["ch1_image"];
      document.querySelector("#ch2").value = data["ch2_text"];
      document.querySelector("#ch2img").value = data["ch2_image"];
      document.querySelector("#ch3").value = data["ch3_text"];
      document.querySelector("#ch3img").value = data["ch3_image"];
      document.querySelector("#ch4").value = data["ch4_text"];
      document.querySelector("#ch4img").value = data["ch4_image"];
      document.querySelector("#ch5").value = data["ch5_text"];
      document.querySelector("#ch5img").value = data["ch5_image"];
      document.querySelector("#ch6").value = data["ch6_text"];
      document.querySelector("#ch6img").value = data["ch6_image"];
      document.querySelector("#answer").value = data["answer"];
      document.querySelector("#solution").value = data["solution"];
      document.querySelector("#status").value = data["status"];
      document.querySelector("#soltype").value = data["solution_type"];
      document.querySelector("#keywords").value = data["keywords"];
      document.querySelector("#lvl").value = data["level"];
      document.querySelector("#videofile").value = data["video_file"];
      document.querySelector("#videosrc").value = data["video_source"];
      document.querySelector("#videolink").value = data["video_link"];
      document.querySelector("#videoduration").value = data["video_duration"];
      document.querySelector("#solutionimage").value = data["solution_image_link"];
    })
    .catch((err) => {
      console.log(err);
    });
});

$("#question-form").on("submit", function (event) {
  let qid = localStorage.getItem("editable");
  var myData = {
    q_text: $("#qtext").val(),
    q_image: $("#qimage").val(),
    q_type: $("#qtype").val(),
    ch1_text: $("#ch1").val(),
    ch1_image: $("#ch1img").val(),
    ch2_text: $("#ch2").val(),
    ch2_image: $("#ch2img").val(),
    ch3_text: $("#ch3").val(),
    ch3_image: $("#ch3img").val(),
    ch4_text: $("#ch4").val(),
    ch4_image: $("#ch4img").val(),
    ch5_text: $("#ch5").val(),
    ch5_image: $("#ch5img").val(),
    ch6_text: $("#ch6").val(),
    ch6_image: $("#ch6img").val(),
    // answer: $("#answer").val(),
    solution: $("#solution").val(),
    status: "active",
    solution_type: $("#soltype").val(),
    keywords: $("#keywords").val(),
    level: $("#lvl").val(),
    video_file: $("#videofile").val(),
    video_source: $("#videosrc").val(),
    video_link: $("#videolink").val(),
    video_duration: $("#videoduration").val(),
    solution_image_link: $("#solutionimage").val(),
    modified: new Date()
  };

  console.log(myData);

  axios
    .patch(
      `https://x7j15x2iil.execute-api.ap-south-1.amazonaws.com/Prod/question/${qid}`,
      myData
    )
    .then((res) => {
      alert("Question Updated");
      window.location.href = './questions.html'
    })
    .catch((err) => {
      console.log(err);
      alert("Unable to update");
    });

  event.preventDefault();
});
