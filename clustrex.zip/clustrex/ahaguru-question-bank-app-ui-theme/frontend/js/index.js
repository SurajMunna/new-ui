$(document).ready(function () {
  $("#question-form").on("submit", function (event) {
    var myData = {
      q_text: $("#qtext").val(),
      q_image: $("#qimage").val(),
      q_type: $("#qtype").val(),
      ch1_text: $("#ch1").val(),
      ch1_image: $("#ch1img").val(),
      ch2_text: $("#ch2").val(),
      ch2_image: $("#ch2img").val(),
      ch3_text: $("#ch3").val(),
      ch3_image: $("#ch3img").val(),
      ch4_text: $("#ch4").val(),
      ch4_image: $("#ch4img").val(),
      ch5_text: $("#ch5").val(),
      ch5_image: $("#ch5img").val(),
      ch6_text: $("#ch6").val(),
      ch6_image: $("#ch6img").val(),
      answer: $("#answer").val(),
      solution: $("#solution").val(),
      status: "active",
      solution_type: $("#soltype").val(),
      keywords: $("#keywords").val(),
      level: $("#lvl").val(),
      video_file: $("#videofile").val(),
      video_source: $("#videosrc").val(),
      video_link: $("#videolink").val(),
      //video_duration: $("#videoduration").val(),
      solution_image_link: $("#solutionimage").val(),
      created: new Date(),
      created_by:1609750062
    };

    console.log(myData);

    axios
      .post(
        "https://x7j15x2iil.execute-api.ap-south-1.amazonaws.com/Prod/question",
        myData
      )
      .then((res) => {
        alert("Inserted");
      })
      .catch((err) => {
        alert("Unable to Insert");
      });
    event.preventDefault();
  });
});
