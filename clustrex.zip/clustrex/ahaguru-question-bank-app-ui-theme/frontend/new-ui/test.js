
function runthisforme(){
    selectedValues = $('#select_test').val();
    console.log(selectedValues)
}