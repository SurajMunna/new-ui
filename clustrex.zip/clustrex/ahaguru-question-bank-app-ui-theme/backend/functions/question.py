import json
from utils import sqlFetch,cursor_to_list,internalError,getSuccess,postSuccess
import time
from datetime import datetime

def getQuestionTable(event,context):
    conn, cursor = sqlFetch()
    querystring= event["queryStringParameters"]
    try:
        if querystring == None or len(querystring) == 0 :
            cursor.execute("select * from dev.question;")    
            json_data = json.dumps(cursor_to_list(cursor),default=str)
            return getSuccess(json_data)
        else:
            if 'status' in querystring.keys():
                cursor.execute("select * from dev.question where status='" + querystring["status"]+ "';")
                json_data = json.dumps(cursor_to_list(cursor),default=str)         
                return getSuccess(json_data)
            if 'createdby' in querystring.keys():
                cursor.execute("select * from dev.question where created_by='" + querystring["createdby"]+ "';")
                json_data = json.dumps(cursor_to_list(cursor),default=str)         
                return getSuccess(json_data)
            if 'limit' in querystring.keys():
                if 'offset' in querystring.keys():
                    cursor.execute("select * from dev.question order by id limit " + str(querystring['limit'])+" offset " + str(querystring['offset']) + ";")
                    json_data = json.dumps(cursor_to_list(cursor),default=str)         
                    return getSuccess(json_data)
                else:
                    cursor.execute("select * from dev.question order by id limit " + str(querystring['limit']) + ";")
                    json_data = json.dumps(cursor_to_list(cursor),default=str)         
                    return getSuccess(json_data)
            else:
                return internalError("invalid queryString parms")                            
    except Exception as e:
        return internalError(e)

def getQuestionID(event,context):
    conn, cursor = sqlFetch()
    try:
        table_id=event['pathParameters']['table_id']
        sql_execute="select * from dev.question where id='%s'"%(table_id)
        cursor.execute(sql_execute)
        json_data = json.dumps(cursor_to_list(cursor),default=str)
        return getSuccess(json_data)
    except Exception as e:
        return internalError(e)

def insertQuestion(event,context):
    conn, cursor = sqlFetch()
    try:
        insert_dict = json.loads(event['body'])
        insert_values='('
        for key in insert_dict.keys():
            if key == 'id':
                pass
            else:
                insert_values += "'"+str(insert_dict[key])+"'" + ","
        insert_values = insert_values.strip(",") + ")"       
        heading_list = list(insert_dict.keys())
        if 'id' in heading_list:
            heading_list.remove('id')        
        insert_headings="("   
        for i in heading_list:
            insert_headings+=i+","
        insert_headings=insert_headings.strip(",")+")"
        sql_execute="insert into dev.question " + insert_headings + " values "+insert_values+";"
        cursor.execute(sql_execute)
        conn.commit()
        return postSuccess()
    except Exception as e:
        return internalError(e)

def deleteQuestionID(event,context):
    conn, cursor = sqlFetch()
    try:
        table_id=event['pathParameters']['table_id']
        sql_execute="delete from dev.question where id='%s'"%(table_id)
        cursor.execute(sql_execute)
        conn.commit()
        return postSuccess("Deleted successfully")
    except Exception as e:
        return internalError(e)

def updateQuestion(event,context):
    conn, cursor = sqlFetch()
    try:
        table_id=event['pathParameters']['table_id']
        insert_dict = json.loads(event['body'])
        update_query = "UPDATE dev.question set "
        for key in insert_dict.keys():
            if key == 'id':
                pass
            elif key == 'modified':
                pass
            else:
                update_query += str(key).replace("'","") + "='" + str(insert_dict[key]) + "',"
        
        update_query += "modified='" + str(datetime.now()) + "'"
        update_query += " where id='%s'"%(table_id)               
        cursor.execute(update_query)
        conn.commit()
        return postSuccess()
    except Exception as e:
        return internalError(e)                
