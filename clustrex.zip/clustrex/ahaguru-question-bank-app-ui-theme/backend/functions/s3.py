import os
import json
import boto3
from botocore.client import Config
from utils import getSuccess

ACCESS_KEY = os.environ['access_key']
SECRET_KEY = os.environ['secret_key']


def getS3Resource(event, context):

    s3_client = boto3.client(
        's3',
        config=Config(signature_version='s3v4'),
        aws_access_key_id=ACCESS_KEY,
        aws_secret_access_key=SECRET_KEY
    )

    BUCKET = 'resources.questionbank.ahaguru.com'
    OBJECT = event['headers']['key']
    EXPIRES_IN = 300
    METHOD = 'get_object' if 'method' not in event else event['method']

    response = s3_client.generate_presigned_url(
        METHOD,
        Params={'Bucket': BUCKET, 'Key': OBJECT},
        ExpiresIn=EXPIRES_IN
    )

    return getSuccess(json.dumps(response))


def putS3Resource(event, context):

    s3_client = boto3.client(
        's3',
        config=Config(signature_version='s3v4'),
        aws_access_key_id=ACCESS_KEY,
        aws_secret_access_key=SECRET_KEY
    )

    BUCKET = 'resources.questionbank.ahaguru.com'
    OBJECT = event['headers']['key']
    EXPIRES_IN = 300
    METHOD = 'put_object'

    response = s3_client.generate_presigned_url(
        METHOD,
        Params={'Bucket': BUCKET, 'Key': OBJECT},
        ExpiresIn=EXPIRES_IN
    )

    return getSuccess(json.dumps(response))    