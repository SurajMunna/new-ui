import json
from utils import sqlFetch,cursor_to_list,internalError,getSuccess

def getTable(event,context):
    table_name = event['pathParameters']['table_name']
    conn, cursor = sqlFetch()
    try:
        cursor.execute("select * from dev." + table_name + ";")    
        json_data = json.dumps(cursor_to_list(cursor),default=str)
        return getSuccess(json_data)

    except Exception as e:
        return internalError(e)
