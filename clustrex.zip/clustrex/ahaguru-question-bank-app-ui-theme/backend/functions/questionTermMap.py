import json
from utils import sqlFetch,cursor_to_list,internalError,getSuccess,postSuccess
import time
from datetime import datetime

Main_table_name = 'dev.question_term_map'

def getQuestionTermTable(event,context):
    conn, cursor = sqlFetch()
    querystring= event["queryStringParameters"]
    try:
        if querystring == None or len(querystring) == 0 :
            cursor.execute("select * from "+Main_table_name+";")    
            json_data = json.dumps(cursor_to_list(cursor),default=str)
            return getSuccess(json_data)
        else:
            if 'limit' in querystring.keys():
                if 'offset' in querystring.keys():
                    cursor.execute("select * from "+Main_table_name+" order by id limit " + str(querystring['limit'])+" offset " + str(querystring['offset']) + ";")
                    json_data = json.dumps(cursor_to_list(cursor),default=str)         
                    return getSuccess(json_data)
                else:
                    cursor.execute("select * from "+Main_table_name+" order by id limit " + str(querystring['limit']) + ";")
                    json_data = json.dumps(cursor_to_list(cursor),default=str)         
                    return getSuccess(json_data)
            else:
                return internalError("invalid queryString parms")                            
    except Exception as e:
        return internalError(e)

def getQuestionTermID(event,context):
    conn, cursor = sqlFetch()
    try:
        table_id=event['pathParameters']['table_id']
        sql_execute="select * from "+Main_table_name+" where id='%s'"%(table_id)
        cursor.execute(sql_execute)
        json_data = json.dumps(cursor_to_list(cursor),default=str)
        return getSuccess(json_data)
    except Exception as e:
        return internalError(e)

def insertQuestionTerm(event,context):
    conn, cursor = sqlFetch()
    try:
        insert_dict = json.loads(event['body'])
        insert_values='(' 
        for key in insert_dict.keys():
            if key == 'id':
                pass
            else:
                insert_values += "'"+str(insert_dict[key])+"'" + ","
        insert_values = insert_values.strip(",") + ")"       
        heading_list = list(insert_dict.keys())
        if 'id' in heading_list:
            heading_list.remove('id')   
        insert_headings="("   
        for i in heading_list:
            insert_headings+=i+","
        insert_headings=insert_headings.strip(",")+")"
        sql_execute="insert into "+Main_table_name+" " +insert_headings + " values "+insert_values+";"
        cursor.execute(sql_execute)
        conn.commit()
        return postSuccess()
    except Exception as e:
        return internalError(e)

def deleteQuestionTermID(event,context):
    conn, cursor = sqlFetch()
    try:
        table_id=event['pathParameters']['table_id']
        sql_execute="delete from "+Main_table_name+" where id='%s'"%(table_id)
        cursor.execute(sql_execute)
        conn.commit()
        return postSuccess("Deleted successfully")
    except Exception as e:
        return internalError(e)

def updateQuestionTerm(event,context):
    conn, cursor = sqlFetch()
    try:
        table_id=event['pathParameters']['table_id']
        insert_dict = json.loads(event['body'])
        update_query = "UPDATE "+Main_table_name+" set "
        for key in insert_dict.keys():
            if key == 'id':
                pass
            elif key == 'modified':
                pass
            else:
                update_query += str(key).replace("'","") + "='" + str(insert_dict[key]) + "',"
        
        update_query += "modified='" + str(datetime.now()) + "'"
        update_query += " where id='%s'"%(table_id)              
        cursor.execute(update_query)
        conn.commit()
        return postSuccess()
    except Exception as e:
        return internalError(e)                
